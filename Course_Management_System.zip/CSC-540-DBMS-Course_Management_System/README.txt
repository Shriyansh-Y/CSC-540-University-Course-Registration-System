Team Members-

Names				Unity id
Anuraag Motiwale		asmotiwa
Abhishek Singh			aksingh5
Parag Nakhwa			psnakhwa
Shriyansh Yadav			scyadav



Instructions to run the application:
1. First, execute the sql_queries.sql file to create tables, triggers and procedures.
2. Execute the insert_sample_data.sql file to insert sample data in the database.
3. Run the CourseRegistration.jar file and login to the database where the sample data 
   is populated.
4. Below are the initial login credentials for the users:

	Admin-
	Username		Password
	alby   			hogwarts
	
	Student-
	Username		Password
	hpotter			101
	hgranger		102
	rweasley		103
	dmalfoy			104
