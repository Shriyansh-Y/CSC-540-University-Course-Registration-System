package javaCode;

public class SpecialPermissionCourses {
	public String course_id;
	public String cname;
	public String fname;
	public String sem;
	public String status;
}
