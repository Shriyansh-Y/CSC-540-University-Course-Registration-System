package javaCode;

public class GradeReport {
	public String cid;
	public String course_name;
	public String sem;
	public String grade;

	
}
