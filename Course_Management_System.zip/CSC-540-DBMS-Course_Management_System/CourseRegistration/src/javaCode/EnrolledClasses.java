package javaCode;

public class EnrolledClasses {
	public String cid;
	public String sem;
	public String course_name;
	public String lgrade;
}
